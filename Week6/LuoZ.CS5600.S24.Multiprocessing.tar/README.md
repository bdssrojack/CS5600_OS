To run the program: `make` then `./main`

To check it's working: checkout the `tmp.txt` for the randomly generated words, and text files in `/output` for encoded sentence.

To run in test mode, type `make test` then `./test`